export const domicileLocation = [
  {
    id: "1",
    value: "Andaman and Nicobar Islands",
  },
  {
    id: "2",
    value: "Andhra Pradesh",
  },
  {
    id: "3",
    value: "Arunachal Pradesh",
  },
  {
    id: "4",
    value: "Assam",
  },
  {
    id: "5",
    value: "Bihar",
  },
  {
    id: "6",
    value: "Chandigarh",
  },
  {
    id: "7",
    value: "Chhattisgarh",
  },
  {
    id: "8",
    value: "Dadra and Nagar Haveli",
  },
  {
    id: "9",
    value: "Daman and Diu",
  },
  {
    id: "10",
    value: "Delhi",
  },
  {
    id: "11",
    value: "Goa",
  },
  {
    id: "12",
    value: "Gujarat",
  },
  {
    id: "13",
    value: "Haryana",
  },
  {
    id: "14",
    value: "Himachal Pradesh",
  },
  {
    id: "15",
    value: "Jammu and Kashmir",
  },
  {
    id: "16",
    value: "Jharkhand",
  },
  {
    id: "17",
    value: "Karnataka",
  },
  {
    id: "18",
    value: "Kerala",
  },
  {
    id: "19",
    value: "Ladakh",
  },
  {
    id: "20",
    value: "Lakshadweep",
  },
  {
    id: "21",
    value: "Madhya Pradesh",
  },
  {
    id: "22",
    value: "Maharashtra",
  },
  {
    id: "23",
    value: "Manipur",
  },
  {
    id: "24",
    value: "Meghalaya",
  },
  {
    id: "25",
    value: "Mizoram",
  },
  {
    id: "26",
    value: "Nagaland",
  },
  {
    id: "27",
    value: "Odisha",
  },
  {
    id: "28",
    value: "Puducherry",
  },
  {
    id: "29",
    value: "Punjab",
  },
  {
    id: "30",
    value: "Rajasthan",
  },
  {
    id: "31",
    value: "Sikkim",
  },
  {
    id: "32",
    value: "Tamil Nadu",
  },
  {
    id: "33",
    value: "Telangana",
  },
  {
    id: "34",
    value: "Tripura",
  },
  {
    id: "35",
    value: "Uttar Pradesh",
  },
  {
    id: "36",
    value: "Uttarakhand",
  },
  {
    id: "37",
    value: "West Bengal",
  },
];
