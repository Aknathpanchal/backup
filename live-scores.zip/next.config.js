/** @type {import('next').NextConfig} */
const nextConfig = {
    env:{
        MONGODB_URI:"mongodb+srv://shreedpanchal1999:shree1999@cluster0.r7xwdua.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
    }
}

module.exports = nextConfig
