export interface ITask {
    _id:string,
    matchName:string;
    sport: string;
    team1: string;
    team2: string;
    score: string;
    time: string;
}

