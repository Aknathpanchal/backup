import mongoose, { Schema, Document } from 'mongoose';

// Define the Match interface extending Document
interface Match extends Document {
  matchName:string;
  sport: string;
  team1: string;
  team2: string;
  score: string;
  time: string;
}

// Define the schema for Match
const matchSchema = new Schema<Match>({
  matchName: { type: String, required: true },
  sport: { type: String, required: true },
  team1: { type: String, required: true },
  team2: { type: String, required: true },
  score: { type: String, required: true },
  time: { type: String, required: true }
});

// Export the Match model
export const Match = mongoose.models.Match || mongoose.model<Match>("Match", matchSchema);
