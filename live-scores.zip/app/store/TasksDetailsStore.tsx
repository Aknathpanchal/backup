// "use client";

import { ITask } from "../../types/tasks";
import { IRootStore } from "./RootStore";
import { action, computed, makeObservable, observable } from "mobx";


export class TasksDetailsStore {
  tasksDetails: ITask[] = [];
  taskDetail: ITask = {} as ITask;
  rootStore: IRootStore;


  constructor(rootStore: IRootStore) {
    this.rootStore = rootStore;
    makeObservable(this, {
      tasksDetails: observable,
      taskDetail:observable,
      fetchTasksDetails: action,
      getTasksDetails: computed,
      getTaskDetail: computed,
    });
  }


  async fetchTasksDetails() {
    const response = await fetch(`api/live-scores`);
    const data = await response.json();
    console.log("Response",data)
    this.tasksDetails = data.seatstatus;
  }


  get getTasksDetails() {
    return this.tasksDetails;
  }


  get getTaskDetail() {
    return this.taskDetail;
  }


  async getSingleTask(id: string){
    const res = await fetch(`api/tasks/${id}`);
    const singleTask = await res.json();
    this.taskDetail = singleTask;
  };

}




