"use client";

import { ITask } from "../../types/tasks";
import { observer } from "mobx-react-lite";

interface TaskProps {
  task: ITask;
  index: number;
}

const sportImages: Record<string, string> = {
  football: '/images/fooball.png',
  basketball: '/images/basketball.png',
  tennis: '/images/tenis.png',
  cricket: '/images/cricket.png'
  // Add more sports and their images here
};

const Task: React.FC<TaskProps> = observer(({ task, index }) => {
  return (
    <tr key={task._id}>
      <td className="text-center">
        {index + 1}
      </td>
      <td className="text-center flex gap-2">
      <div>
        <img
          src={sportImages[task.sport] || '/images/default.png'}
          alt={task.sport}
          className="w-8 h-8"
        />
        </div>
        <div className="text-center justify-center flex items-center">{task.matchName}</div>
        
      </td>
      <td className="text-center">
        {task.team1} And {task.team2}
      </td>
      <td className="text-center">
        {task.score}
      </td>
      <td className="text-center">
        {task.time}
      </td>
    </tr>
  );
});

export default Task;

