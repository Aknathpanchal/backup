// "use client";

// import { ITask } from "../../types/tasks";
// import Task from "./Task";

// interface TodoListProps {
//   tasks: ITask[];
// }

// const TodoList: React.FC<TodoListProps> = ({ tasks }) => {
//   return (
//     <div className="overflow-x-auto">
//       <table className="table table-zebra">
//         <thead>
//           <tr>
//             <th className="text-center">Sr.No.</th>
//             <th className="text-center">Match Name</th>
//             <th className="text-center">Teams</th>
//             <th className="text-center">Score</th>
//             <th className="text-center">Time</th>
//           </tr>
//         </thead>
//         <tbody>
//           {tasks?.map((task, taskIndex) => (
//             <Task
//               key={task._id}
//               task={task}
//               index={taskIndex}
//             />
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default TodoList;


"use client";

import { useState } from "react";
import { ITask } from "../../types/tasks";
import Task from "./Task";

interface TodoListProps {
  tasks: ITask[];
}

const TodoList: React.FC<TodoListProps> = ({ tasks }) => {
  const [selectedSport, setSelectedSport] = useState<string>('All');

  const handleSportChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSport(event.target.value);
  };

  const filteredTasks = selectedSport === 'All' ? tasks : tasks.filter(task => task.sport === selectedSport);

  const sportsOptions = Array.from(new Set(tasks.map(task => task.sport))).concat('All');

  return (
    <div>
      <div className="mb-4">
        <label htmlFor="sport-select" className="mr-2">Filter by Sport:</label>
        <select
          id="sport-select"
          className="select"
          value={selectedSport}
          onChange={handleSportChange}
        >
          {sportsOptions.map(sport => (
            <option key={sport} value={sport}>
              {sport}
            </option>
          ))}
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="table table-zebra min-w-full">
          <thead>
            <tr>
              <th className="text-center">Sr.No.</th>
              <th className="text-center">Match Name</th>
              <th className="text-center">Teams</th>
              <th className="text-center">Score</th>
              <th className="text-center">Time</th>
            </tr>
          </thead>
          <tbody>
            {filteredTasks.map((task, taskIndex) => (
              <Task
                key={task._id}
                task={task}
                index={taskIndex}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TodoList;

