import { dbConnect } from "../../../utils/connection/connection";
import { Match } from "../../../utils/model/model";
import { NextResponse } from "next/server";


export const GET = async () => {
  await dbConnect();
  try {
    const seatstatus = await Match.find();
    return NextResponse.json({ seatstatus }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { massage: `request failed due to ${error.massage}`},
      { status: 404 }
    );
  }
};