
# Live Sports Scores Web Application

## Overview

This web application displays live scores and fixtures for sports events. Developed using React, Node.js, and Next.js, the application fetches data from an API and presents it in a responsive and visually appealing manner. It also features filtering functionality to view scores based on a selected sport.

## Features

- **Live Scores Display:** Shows live scores, teams, and match times.
- **Responsive Design:** Scores and fixtures are displayed in a responsive grid or table format.
- **Sport Filtering:** Allows users to filter scores based on a selected sport.

## Technologies Used

- **Frontend:** React, Next.js, Tailwind CSS, DaisyUI
- **Backend:** Node.js, Express
- **Database:** MongoDB
- **Others:** TypeScript, MobX

## Installation

1. **Clone the Repository:**

   ```bash
   git clone [REPOSITORY_URL]
   cd [PROJECT_DIRECTORY]
   ```

2. **Install Dependencies:**

   ```bash
   npm install
   ```

3. **Configuration:**

   Update the `next.config.js` file with your MongoDB URI. Replace the existing URI with your own if needed.

   ```js
   /** @type {import('next').NextConfig} */
   const nextConfig = {
       env: {
           MONGODB_URI: "mongodb+srv://your_mongodb_uri_here"
       }
   }

   module.exports = nextConfig
   ```

4. **Run the Application:**

   ```bash
   npm run dev
   ```

   The application will run on `http://localhost:3001`.

## API Proxy

The Node.js server is configured to run on port `3001`. It proxies requests to the actual API endpoint. Ensure the server is running to handle API requests.

- **View Data:**

  You can access the live scores data at `http://localhost:3001/api/live-scores`.


## Styling

Tailwind CSS and DaisyUI are used for styling. Custom styles can be added in `globals.css` or using Tailwind utility classes directly in component files.
