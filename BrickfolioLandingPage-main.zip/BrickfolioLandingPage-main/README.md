Brick-Folio

Technologies
HTML5, CSS3, JavaScript
Bootstrap (for responsive design)

Installation
Clone the repo:
bash
Copy code
git clone https://github.com/Pranavkeepway/BrickfolioLandingPage.git

Navigate to the project directory:- Open Folder - brickfolio-landing-page


Usage -

open index.html (or your main HTML file) directly in your browser by double-clicking it.

Contact -
Created by Pranav Kulkarni.
Mobile No. - 8830484199
