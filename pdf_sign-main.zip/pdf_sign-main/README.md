# Sign a pdf with Javascript
Repository to sign pdfs using PDF-LIB.js and node-signpdf

## Install
* Clone repo
* Then install dependencies

```
npm i
```

## Usage
* Open src/index.js
* Update the two arguments in for SignPDF class (if you do not want to use the test ones)
* create a folder called `exports` in the root of the project
* Then run this command in your terminal
```
npm start
```
